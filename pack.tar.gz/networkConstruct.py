import torch
from torch import nn
import torchvision.models as models
import torch.nn.functional as F


#%% LSTM model
class lstmModel(nn.Module):
    def __init__(self, in_shape, out_shape, cfg):
        super(lstmModel, self).__init__()
        self.cfg = cfg
        
        self.dataMeanPara = torch.nn.parameter.Parameter(data=cfg.data_mean_std[0], requires_grad=False)
        self.dataStdPara = torch.nn.parameter.Parameter(data=cfg.data_mean_std[1], requires_grad=False)
        
        if '1' in cfg.net_type:     # 106
            num_neuron,num_layers,dropout = 20,2,0.2
        elif '2' in cfg.net_type:
            num_neuron,num_layers,dropout = 128,2,0.2
        elif '3' in cfg.net_type:
            num_neuron,num_layers,dropout = 128,4,0.5
        elif '4' in cfg.net_type:
            num_neuron,num_layers,dropout = 128,1,0
        elif '5' in cfg.net_type:
            num_neuron,num_layers,dropout = 64,8,0.2
        elif '6' in cfg.net_type:    
            num_neuron,num_layers,dropout = 20,2,0
        else:
            num_neuron,num_layers,dropout = 128,4,0.2

        D = 2 if cfg.bid else 1
        self.lstm = nn.LSTM(in_shape[-1], num_neuron, num_layers=num_layers, dropout=dropout, bidirectional=cfg.bid)
        self.linear = nn.Linear(num_neuron*D, out_shape[1])
    
    def forward(self, x):
        x = x.permute((1,0,2))
        x = (x-self.dataMeanPara)/self.dataStdPara
        x = self.lstm(x)[0][-1]   # output at the last time step
        x = self.linear(x)
        return x
        

       
#%% setup model
def setupModel(in_shape, out_shape, cfg):
    net_type = cfg['net_type']

    if 'lstm' in net_type:
        model = lstmModel(in_shape, out_shape, cfg).to(cfg.device)
        
        # init LSTM
        if cfg.lstm_init:
            for name, param in model.lstm.named_parameters():
                if name.startswith('weight'):
                    nn.init.orthogonal_(param)
    else:
        pass

    return model