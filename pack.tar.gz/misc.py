import os
from functools import partial
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import ptvsd
import torch

# set environment variables
def setEnv():
    # os.environ['HDF5_DISABLE_VERSION_CHECK'] = '1'
    # matplotlib.use("Qt5Agg")
    pass


printf = partial(print, flush=True)

# print color text
class Cr:
    r = '\033[91m'  # red
    g = '\033[6;30;42m'  # green
    e = '\033[0m'  # end


# %% Show CDF
def plotCDF(error_naive, error_ai, fig_id, show=True):
    bins_count0, cdf0 = getCdf(error_naive*1000, 4000)
    bins_count, cdf = getCdf(error_ai*1000, 4000)

    plt.plot(bins_count0, cdf0, label='naive')
    plt.plot(bins_count, cdf, label='LSTM')

    x_target = bins_count[findNearest(cdf, 0.9)]
    plt.scatter(x_target, 0.9, s=50, color='red')
    plt.annotate('(%0.2f, 0.9)' % x_target, xy=(x_target, 0.9), xytext=(x_target, 0.85))
    plt.plot([x_target, x_target], [0.9, 0], 'g--', lw=2)

    plt.grid()
    plt.axis([0, 50, 0, 1.1])
    plt.xlabel('Prediction error / ms')
    plt.ylabel('CDF')
    plt.legend()
    mg = plt.get_current_fig_manager()
    mg.window.move(200+fig_id*50, 200+fig_id*50)
    mg.set_window_title('CDF')
    if show:
        plt.show()


def findNearest(array, value):
    idx, val = min(enumerate(array), key=lambda x: abs(x[1]-value))
    return idx

# get CDF
def getCdf(data, num_bins):
    count, bins_count = np.histogram(data, num_bins)
    pdf = count / sum(count)
    cdf = np.cumsum(pdf)
    return bins_count[1:], cdf

# %% plot training/test error vs epoch
def plotErrorChange(errors, tag, fig_id):
    errors = np.array(errors)
    plt.plot(errors[:, 0], errors[:, 1])
    plt.grid()
    plt.xlabel('Epoch')
    plt.ylabel('Prediction error / m')
    plt.title(tag)
    mg = plt.get_current_fig_manager()
    mg.window.move(200+fig_id*50, 200+fig_id*50)
    mg.set_window_title(tag)
    plt.show()

#%% plot label and prediction
def plotInterval(test_loader, pred):
    labels = torch.cat([i for (_,i) in test_loader]).numpy()

    plt.plot(np.arange(len(labels)), labels*1000, label='True')
    plt.plot(np.arange(len(pred)), pred*1000, label='Prediction')
    plt.grid()
    plt.xlabel('Sample')
    plt.ylabel('Interval / ms')
    plt.title('true vs predicted')
    plt.show()

# %% debug
def waitDebugAttach():
    host = "127.0.0.1" # or "localhost"
    port = 12345
    print("Waiting for debugger attach at %s:%s ......" % (host, port))
    ptvsd.enable_attach(address=(host, port), redirect_output=True)
    ptvsd.wait_for_attach()

    
    