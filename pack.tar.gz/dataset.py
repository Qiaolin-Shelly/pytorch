import numpy as np
import torch
from torch.utils.data import Dataset, TensorDataset, DataLoader
import pdb
import pandas
from statsmodels.stats.diagnostic import acorr_ljungbox
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.stattools import kpss
import statsmodels.api as sm
import matplotlib.pyplot as plt

from misc import Cr


class MyDataset(Dataset):
    def __init__(self, series, size, cfg, dataType):
        N = series.shape[0]

        TrainNum = int((N*(1-cfg.split_ratio)))


        if dataType == 'train':
            series = series[:TrainNum]

        elif dataType == 'test':
            series = series[TrainNum:]

        self.seq_len = size[0]
        self.pred_len = size[1]
        self.series = torch.tensor(series)
        self.x_shape = [self.series.shape[0]-(self.seq_len+self.pred_len)+1, self.seq_len, self.series.shape[1]]
        self.y_shape = [self.x_shape[0], self.pred_len]
        

    def __len__(self):
        return self.x_shape[0]

    def __getitem__(self, idx):  
        x = self.series[idx:idx+self.seq_len]
        y = self.series[idx+self.seq_len:idx+self.seq_len+self.pred_len].squeeze(dim=1)

        return (x, y)


# get dataloader from file
def getDataLoader(cfg, pseudo_label=False, model=None):
    print('The current dataset is : %s' % (cfg.file_data))
    series = pandas.read_csv(cfg.file_data, index_col=0).values.astype(np.float32)
    
    # 1-order
    series_diff = np.diff(series, axis=0)
    if cfg.data_len > 0:
        series_diff = series_diff[:cfg.data_len]
    
    # series_diff = np.arange(1000).astype(np.float32)
    
    # dataAnalysis(series_diff)
    
    size = [cfg.len_seq, cfg.len_pred]
    train_dataset = MyDataset(series_diff, size, cfg, 'train')
    test_dataset = MyDataset(series_diff, size, cfg, 'test')

    data_mean_std = getMeanStd(train_dataset)

    train_loader = DataLoader(dataset=train_dataset,
                              batch_size=cfg.batch_size,
                              shuffle=True,
                              drop_last=True)
    test_loader = DataLoader(dataset=test_dataset,
                             batch_size=cfg.batch_size,
                             shuffle=False,
                             drop_last=False)
    
    
    print(f'train dataset shape: {train_dataset.__len__()}')
    print(f'test dataset shape: {test_dataset.__len__()}')

    return train_loader, test_loader, data_mean_std


#%% get mean and std
def getMeanStd(train_dataset):
    dataMean = train_dataset.series.mean()
    dataStd = train_dataset.series.std()
    return [dataMean,dataStd]


#%% data analysis
def dataAnalysis(series):
    
    # Ljung-Box test: white noise
    p_value = acorr_ljungbox(series, lags=6)
    if p_value.lb_pvalue.values[-1] < 0.05:
        print(f'{Cr.g}Non white noise test passed!{Cr.e}')
    else:
        print(f'{Cr.r}Non white noise test NOT passed!{Cr.e}')
    
    # ADF test: Stationarity
    dftest = adfuller(series)
    if dftest[1]<0.05 and dftest[0]<dftest[4]['1%']:
        print(f'{Cr.g}ADF test passed!{Cr.e}')
    else:
        print(f'{Cr.r}ADF test NOT passed!{Cr.e}')
        
        
    # acf for difference order [d] and MA order [q]
    sm.graphics.tsa.plot_acf(series)  # d=0, q=1
    
    # pacf for AR order [p]
    sm.graphics.tsa.plot_pacf(series, method='ywm') # p=1
    
    plt.show()