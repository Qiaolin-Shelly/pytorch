import h5py
import numpy as np
import argparse
import copy
from tqdm import trange
import time
import psutil
import os
import multiprocessing as mp

import torch
import torch.nn as nn
from thop import profile
from thop import clever_format
from tensorboardX import SummaryWriter

import misc
from misc import printf, Cr
import AInetwork
import dataset
import networkConstruct



if __name__ == '__main__':
    # %%
    # config
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--batch_size', default=32, type=int)
    parser.add_argument('--bid', action='store_true', help='bidirectional LSTM')
    parser.add_argument('--checkpoint_version', default=-1, type=int,
                        help='-1 means latest version, 0 means latest checkpoint_# version')
    parser.add_argument('--data_len', default=-1, type=int)
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--epoch', default=1, type=int, help='epoch num')
    parser.add_argument('--file_data', default='../data/UDP_original_onlytime_phy_partial.csv', type=str, help='file name')
    parser.add_argument('--gpu', default=0, type=int, help='gpu device')
    parser.add_argument('--grad_clip', action='store_true')
    parser.add_argument('--len_pred', default=1, type=int)
    parser.add_argument('--len_seq', default=100, type=int)
    parser.add_argument('--loss_fun', default='L1', type=str,help='loss function: L1, L2, MSE')
    parser.add_argument('--lr', default=1e-4, type=float, help='learning rate')
    parser.add_argument('--lstm_init', action='store_true')
    parser.add_argument('--net_type', default='lstm', type=str, help='select AI network')
    parser.add_argument('--not_plot', action='store_true')
    parser.add_argument('--num_threads', default=8, type=int)
    parser.add_argument('--platform', default='auto', type=str, help='running platform: gpu, cpu, or auto')
    parser.add_argument('--run_path', default='runs', type=str)
    parser.add_argument('--split_ratio', default=0.2,type=float, help='learning rate')
    parser.add_argument('--suffix', default='r', type=str)
    parser.add_argument('--test_only', action='store_true')
    parser.add_argument('--verbose', default=1, type=int)

    misc.setEnv()

    args = parser.parse_args()
    cfg = AInetwork.parConfig(args)
    
    if cfg.debug:
        misc.waitDebugAttach()

    # read data
    train_loader, test_loader, data_mean_std = dataset.getDataLoader(cfg)
    cfg.data_mean_std = data_mean_std           # save to model parameter

    # %%
    # AI model
    in_shape, out_shape = train_loader.dataset.x_shape, train_loader.dataset.y_shape
    model = networkConstruct.setupModel(in_shape, out_shape, cfg)
    print(model)

    
    # debug
    # misc.debugAlignModel(model, int(cfg.model_save.split('_')[1][0]), test_loader, cfg.device)
    
    model_flops = networkConstruct.setupModel(in_shape, out_shape, cfg).to('cpu')
    flops, params = profile(model_flops, inputs=(torch.rand([1]+in_shape[1:]),))
    flops, params = clever_format([flops, params], '%.3f')
    print(f'FLOPs = {Cr.g}{flops}{Cr.e}, PARAMS = {Cr.g}{params}{Cr.e}, input = {[1]+in_shape[1:]}')

    lossFun = AInetwork.getLossFun(cfg)

    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.lr)

    # %%
    # Run init
    if not cfg['test_only']:
        writer = SummaryWriter(cfg['writer_path'], flush_secs=1)
        # writer.add_graph(model, train_loader.dataset.x[0:1])
    checkpoint = AInetwork.fetchCheckpoint(
        cfg['writer_path'], cfg.device, False, cfg['checkpoint_version'])
    if checkpoint is None:
        epoch = 1
        trainErrors = []
        testErrors = []
    else:
        epoch = checkpoint['epoch']+1
        trainErrors = checkpoint['trainErrors'] if 'trainErrors' in checkpoint.keys() else []
        testErrors = checkpoint['testErrors'] if 'testErrors' in checkpoint.keys() else []
        model.load_state_dict(checkpoint['model_state_dict'])
        # import pdb;pdb.set_trace()
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        optimizer.param_groups[0]['lr'] = cfg.lr

    # %%
    # Run
    if not cfg['test_only']:
        for t in trange(cfg['epoch']):
            timeStart = time.time()
            printf(f"\n ------------------------------- \nEpoch {epoch}")
            trainLoss, trainErrorMean = AInetwork.netTrain(train_loader, model, lossFun, optimizer, cfg.device, cfg)
            testError, testErrorMean,_,_ = AInetwork.netTest(test_loader, model, cfg.device)

            writer.add_scalar('training loss', trainLoss, epoch)
            writer.add_scalar('training error', trainErrorMean, epoch)
            writer.add_scalar('test error', testErrorMean, epoch)
            trainErrors.append((epoch, trainErrorMean))
            testErrors.append((epoch, testErrorMean))

            # checkpoint
            if epoch % 2000 == 1 or t == cfg['epoch'] - 1:
                torch.save({
                    'epoch': epoch,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                }, f"{cfg['writer_path']}/checkpoint_{epoch:d}.pth")
            if epoch % 100 == 1 or t == cfg['epoch'] - 1:
                torch.save({
                    'epoch': epoch,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'trainErrors': trainErrors,
                    'testErrors': testErrors,
                }, f"{cfg['writer_path']}/checkpoint.pth")
            epoch += 1

        # debug
        if cfg['verbose']:
            printf(f'Memory usage: {psutil.Process(os.getpid()).memory_info().rss / (1024 ** 2):.2f} MB')
        timeCost = time.time() - timeStart
        printf(f'Time usage: {timeCost:.3f} s')
        printf('')

    # %%
    # Show test results
    if not cfg['not_plot'] or cfg['test_only']:
        testError, testErrorMean, preds, pred_errors_naive = AInetwork.netTest(test_loader, model, cfg.device)
        mp.Process(target=misc.plotCDF, args=(pred_errors_naive, testError, 0)).start()
        mp.Process(target=misc.plotErrorChange, args=(trainErrors, 'training error', 1)).start()
        mp.Process(target=misc.plotErrorChange, args=(testErrors, 'test error', 2)).start()
        mp.Process(target=misc.plotInterval, args=(test_loader, preds)).start()
    
    printf("Done!")

else:
    # print("load torch model")
    # model_ckpt = torch.load(model, model_save)
    pass
