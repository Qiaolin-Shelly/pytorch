import torch
from torch import nn
import os
import re
import glob
import collections
import numpy as np
import subprocess
from statsmodels.tsa.arima.model import ARIMA


from misc import printf, Cr

# %% config
class dotdict(dict):
    """dot.notation access to dictionary attributes"""
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


def parConfig(args):

    device = platformSet(args.platform)

    cfg = {
        'batch_size': args.batch_size,
        'bid': args.bid,
        'checkpoint_version': args.checkpoint_version,
        'data_len': args.data_len,
        'debug': args.debug,
        'device': device,
        'epoch': args.epoch,
        'file_data': args.file_data,
        'gpu': args.gpu,
        'grad_clip': args.grad_clip,
        'len_pred': args.len_pred,
        'len_seq': args.len_seq,
        'loss_fun': args.loss_fun,
        'lr': args.lr,
        'lstm_init': args.lstm_init,
        'net_type': args.net_type,
        'not_plot': args.not_plot,
        'num_threads': args.num_threads,
        'split_ratio': args.split_ratio,
        'test_only': args.test_only,
        'verbose': args.verbose,
        'writer_path': f'../rundata/{args.run_path}/{args.suffix}',
    }
    return dotdict(cfg)

# %% select GPU or CPU
def platformSet(platform):
    if platform == 'auto':
        device = torch.device(f'cuda:{findBestGPU()}' if torch.cuda.is_available() else 'cpu')
    elif platform == 'gpu':
        if torch.cuda.is_available():
            device = torch.device(f'cuda:{findBestGPU()}')
        else:
            printf('GPU is not available!')
    else:
        device = torch.device('cpu')
    printf(f'Running on {device.type:s}:{device.index} ...')
    return device

def findBestGPU():
    r = subprocess.getoutput('nvidia-smi --query-gpu=index,utilization.gpu --format=csv')
    gpus = re.findall('\\n(\d+), (\d+)', r)
    bestGpu = -1
    utilization = 100
    for gpu in gpus:
        if int(gpu[1]) <= utilization:
            utilization = int(gpu[1])
            bestGpu = int(gpu[0])
    return bestGpu
    
    

# %% get loss function
def getLossFun(cfg):
    if cfg['loss_fun'] == 'L1':
        lossFn = L1Loss
    elif cfg['loss_fun'] == 'L2':
        lossFn = L2Loss
    elif cfg['loss_fun'] == 'MSE':
        lossFn = nn.MSELoss()
    return lossFn

# MAE loss function: mean(abs(y-l)) = nn.L1Loss()
def L1Loss(output, target):
    loss = torch.mean(torch.norm(output - target, p=1, dim=1)/output.shape[1])
    
    return loss

# loss function: mean(norm2_by_row(y—l))
def L2Loss(output, target):
    loss = torch.mean(torch.norm(output - target, dim=1))
    return loss


# %% fetch checkpoint
def fetchCheckpoint(parameter_path, device, parallel, version):
    checkpoint = None
    para_files = glob.glob(os.path.join(parameter_path, 'checkpoint*.pth'))
    if len(para_files) > 0:
        para_file = os.path.join(parameter_path, f'checkpoint.pth')
        if os.path.exists(para_file):
            printf(f'load checkpoint from {Cr.g}{para_file}{Cr.e}')
            checkpoint = torch.load(para_file, device)
            train_pred_errors = checkpoint['trainPosErrors'] if 'trainPosErrors' in checkpoint.keys() else []
            test_pred_errors = checkpoint['testPosErrors'] if 'testPosErrors' in checkpoint.keys() else []
        else:
            train_pred_errors = []
            test_pred_errors = []
        # import pdb;pdb.set_trace()
        if version >= 0:
            if version == 0:
                para_files = glob.glob(os.path.join(
                    parameter_path, 'checkpoint_*.pth'))
                seq = [int(re.findall(r"checkpoint_(\d+)\.", i)[0])
                       for i in para_files]
                para_file = os.path.join(
                    parameter_path, f'checkpoint_{max(seq):d}.pth')
            elif version > 0:
                para_file = os.path.join(
                    parameter_path, f'checkpoint_{version:d}.pth')
            printf(f'load checkpoint from {Cr.g}{para_file}{Cr.e}')
            checkpoint = torch.load(para_file, device)
        # load from parallel to non-parallel, or non-parallel to parallel
        model_state_dict = collections.OrderedDict()
        keys = checkpoint['model_state_dict'].keys()
        for key in keys:
            if parallel and 'module' not in key:
                model_state_dict[f'module.{key}'] = checkpoint['model_state_dict'][key]
            elif not parallel and 'module' in key:
                model_state_dict[key[7:]] = checkpoint['model_state_dict'][key]
            else:
                model_state_dict[key] = checkpoint['model_state_dict'][key]
        checkpoint['model_state_dict'] = model_state_dict
        if version >= 0:
            checkpoint['trainPosErrors'] = train_pred_errors
            checkpoint['testPosErrors'] = test_pred_errors
    else:
        printf(f'{Cr.r}Warning: No checkpoint file!{Cr.e}')
    # import pdb;pdb.set_trace[}
    return checkpoint

# %% train
def netTrain(data_loader, model, loss_fn, optimizer, device, cfg):
    model.train()
    size = len(data_loader.dataset)
    for batch, (X, y) in enumerate(data_loader):
        X, y = X.to(device), y.to(device)
        
        pred = model(X)
        # if pred.shape[1] == 1:
        #     y = torch.norm(y-y.flip(dims=[0]), dim=1, keepdim=True)
        

        loss = loss_fn(pred, (y-model.dataMeanPara)/model.dataStdPara)

        # Backpropagation
        # optimizer.zero_grad()
        for param in model.parameters():
            param.grad = None
        loss.backward()
        if cfg.grad_clip:
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=2.0)
        optimizer.step()

        if batch % 400 == 0:
            train_loss, current = loss.item(), batch * len(X)
            
            pred_series = (pred.cpu().detach().numpy())*model.dataStdPara.cpu().numpy()+model.dataMeanPara.cpu().numpy()
            pred_error = pred_series - y.cpu().detach().numpy()
            pred_error = np.mean(np.absolute(pred_error), axis=1)   # /model.dataStdPara.numpy()
            
            printf(f"Train loss: {train_loss:>2f}, pred Error: {pred_error.mean():>2f}s [{current:>5d}/{size:>5d}]")
    return loss.item(), pred_error.mean()

# %% test
def netTest(test_loader, model, device):

    pred_errors = np.array([], dtype=np.float32)
    pred_errors_naive = np.array([], dtype=np.float32)   # last value as current value
    preds = np.array([], dtype=np.float32)
    model.eval()
    with torch.no_grad():
        for (X, y) in test_loader:
            X, y = X.to(device), y.to(device)
            
            pred = model(X)
            
            pred_series = pred*model.dataStdPara+model.dataMeanPara

            pred_error = (pred_series - y).cpu().numpy()
            pred_errors = np.append(pred_errors, np.mean(np.absolute(pred_error), axis=1)) 
            preds = np.append(preds, pred_series.cpu().numpy())
            
            pred_errors_naive = np.append(pred_errors_naive, np.mean(np.absolute((X[:,-1,:] - y).cpu().numpy()), axis=1))
            
    printf(f"Test pred error: {Cr.g}{pred_errors.mean():.4f} s{Cr.e} ")
    return pred_errors, pred_errors.mean(), preds, pred_errors_naive


#%% ARIMA
def arima(train_loader, test_loader):
    series_train = train_loader.dataset.series.numpy()
    series_test = test_loader.dataset.series.numpy()
    
    p,d,q = 1,0,1
    model = ARIMA(series_train, order=(p,d,q))
    model_fit = model.fit()
    print(model_fit.summary())
    pass
